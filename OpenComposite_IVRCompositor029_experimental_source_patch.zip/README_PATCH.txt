EXPERIMENTAL IVRCompositor_029 source compatibility patch

This is NOT a compiled DLL and is NOT yet validated in IL-2 BAT 4.3.
It is a source-level compatibility experiment for Rails44/IL2_OpenComposite_patched_source.

Changed files:
- OpenVRHeaders/openvr-2.5.2.h: duplicate 2.5.1 header with compositor interface version updated to 029.
- scripts/split_headers.py: include synthetic 2.5.2 header in the header splitter.
- OpenOVR/Reimpl/CVRCompositor.cpp: register compositor 029 for stub generation.

IMPORTANT: The 029 ABI is ASSUMED to match 028 here. This has NOT been validated
against the actual Valve OpenVR 029 interface definition. Before compiling or
installing, compare 028 and 029 method signatures and vtable order using official
OpenVR headers. If they differ, replace this synthetic header with the actual
029 definition and adapt BaseCompositor/stubs accordingly.

The patch is provided for inspection and refinement. Do NOT overwrite your
known-good 32-bit openvr_api.dll with an unverified build.

To apply: extract these three paths over a separate copy of the source tree.
